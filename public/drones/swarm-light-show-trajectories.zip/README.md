# 100 drones, 91 formations: the flight plan

Timed trajectories for 100 drones through 91 formations, 585 s of show, as planned by the SwarmChoreography example of FSharp.Azure.Quantum (https://github.com/thorium/fsharp.azure.quantum): every change of formation was assigned to the drones by the QAOA block search on 16-qubit circuits and passed the in-flight separation gate.

## Files

- `trajectories/DroneN.csv`: drone N's keyframes, one row when it arrives at a formation and one when it leaves: `t_s,x_m,y_m,z_m,light,formation`. x is east, y north, z up, in metres from the show's origin on the ground. The light is the colour the drone shows from that moment: at a departure it is already the light of the formation it flies to, as the drones set it.
- `show.json`: the formations with their arrival and departure times, the progress law, the speed limits and the origin.

## How the drones move

Between a departure at t0 and the next arrival at t1, every drone moves in a straight line from its departure point to its arrival point, at the same share of its own leg as every other drone: share = 3f² − 2f³ with f = (t − t0) / (t1 − t0). The share is what keeps the plan's separation: the gate checked the straight lines flown together, and under a common law the drones' relative positions at any moment are those lines at that share. A show controller streams these positions at 10 Hz or more (MAVLink: SET_POSITION_TARGET_LOCAL_NED in GUIDED, north = y, east = x, down = −z) and sets the light at each departure.

Each transition takes long enough that the longest leg peaks at 3.0 m/s horizontally, 2.5 m/s climbing, 1.5 m/s descending, and at 1.0 m/s² of acceleration; shorter legs are slower in proportion. A formation is held 3 s, a step that only changes the lights 0.5 s, a step of a deformation or a turn is flown through.

## Figures

- Closest two drones come: 1.77 m, in Ground grid → Globe; the gate's bound is the closest slot spacing / √2 of each transition.
- Origin: 40.786400, -119.206500, 1190.0 m, the site the plan was given; the launch grid stands around it.

## What this is not

These are not waypoint missions. A waypoint mission flies each leg at its own speed, at least 0.5 m/s, and holds the time a short leg saves, so drones with legs of different lengths come apart in time and the plan's separation is lost; the example measured 0.25 m where the plan keeps 2.9 m. A plan is not a permission either: the operator's authorisation, the airspace, the weather limits and the separation the aircraft can hold are the operator's to establish.

MIT licence, as the repository.
